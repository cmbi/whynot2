create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.databank DROP CONSTRAINT fk6e8375063384fb9c;
ALTER TABLE ONLY public.entry DROP CONSTRAINT fk4001852e88539e0;
ALTER TABLE ONLY public.entry DROP CONSTRAINT fk4001852b073cd20;
ALTER TABLE ONLY public.annotation DROP CONSTRAINT fk1a21c74fd01c454;
ALTER TABLE ONLY public.annotation DROP CONSTRAINT fk1a21c74f15e6d2b4;
DROP INDEX public.entry_pdbid_index;
DROP INDEX public.entry_databank_index;
DROP INDEX public.annotation_entry_index;
DROP INDEX public.annotation_comment_index;
ALTER TABLE ONLY public.file DROP CONSTRAINT file_pkey;
ALTER TABLE ONLY public.file DROP CONSTRAINT file_path_key;
ALTER TABLE ONLY public.entry DROP CONSTRAINT entry_pkey;
ALTER TABLE ONLY public.entry DROP CONSTRAINT entry_databank_id_key;
ALTER TABLE ONLY public.databank DROP CONSTRAINT databank_pkey;
ALTER TABLE ONLY public.databank DROP CONSTRAINT databank_name_key;
ALTER TABLE ONLY public.comment DROP CONSTRAINT comment_text_key;
ALTER TABLE ONLY public.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE ONLY public.annotation DROP CONSTRAINT annotation_pkey;
ALTER TABLE ONLY public.annotation DROP CONSTRAINT annotation_comment_id_key;
DROP SEQUENCE public.hibernate_sequence;
DROP TABLE public.file;
DROP TABLE public.entry;
DROP TABLE public.databank;
DROP TABLE public.comment;
DROP TABLE public.annotation;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: annotation; Type: TABLE; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE TABLE annotation (
    id bigint NOT NULL,
    "timestamp" bigint,
    comment_id bigint NOT NULL,
    entry_id bigint NOT NULL
);


ALTER TABLE public.annotation OWNER TO whynotadmin;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE TABLE comment (
    id bigint NOT NULL,
    text character varying(200) NOT NULL
);


ALTER TABLE public.comment OWNER TO whynotadmin;

--
-- Name: databank; Type: TABLE; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE TABLE databank (
    id bigint NOT NULL,
    crawltype character varying(255) NOT NULL,
    filelink character varying(200) NOT NULL,
    name character varying(50) NOT NULL,
    reference character varying(200) NOT NULL,
    regex character varying(50) NOT NULL,
    parent_id bigint
);


ALTER TABLE public.databank OWNER TO whynotadmin;

--
-- Name: entry; Type: TABLE; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE TABLE entry (
    id bigint NOT NULL,
    pdbid character varying(10) NOT NULL,
    databank_id bigint NOT NULL,
    file_id bigint
);


ALTER TABLE public.entry OWNER TO whynotadmin;

--
-- Name: file; Type: TABLE; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE TABLE file (
    id bigint NOT NULL,
    path character varying(200) NOT NULL,
    "timestamp" bigint NOT NULL
);


ALTER TABLE public.file OWNER TO whynotadmin;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: whynotadmin
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO whynotadmin;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: whynotadmin
--

SELECT pg_catalog.setval('hibernate_sequence', 6869868, true);


--
-- Data for Name: annotation; Type: TABLE DATA; Schema: public; Owner: whynotadmin
--

--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: whynotadmin
--

--
-- Data for Name: databank; Type: TABLE DATA; Schema: public; Owner: whynotadmin
--

--
-- Data for Name: entry; Type: TABLE DATA; Schema: public; Owner: whynotadmin
--

--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: whynotadmin
--

--
-- Name: annotation_comment_id_key; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY annotation
    ADD CONSTRAINT annotation_comment_id_key UNIQUE (comment_id, entry_id);


--
-- Name: annotation_pkey; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY annotation
    ADD CONSTRAINT annotation_pkey PRIMARY KEY (id);


--
-- Name: comment_pkey; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: comment_text_key; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_text_key UNIQUE (text);


--
-- Name: databank_name_key; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY databank
    ADD CONSTRAINT databank_name_key UNIQUE (name);


--
-- Name: databank_pkey; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY databank
    ADD CONSTRAINT databank_pkey PRIMARY KEY (id);


--
-- Name: entry_databank_id_key; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY entry
    ADD CONSTRAINT entry_databank_id_key UNIQUE (databank_id, pdbid);


--
-- Name: entry_pkey; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY entry
    ADD CONSTRAINT entry_pkey PRIMARY KEY (id);


--
-- Name: file_path_key; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY file
    ADD CONSTRAINT file_path_key UNIQUE (path, "timestamp");


--
-- Name: file_pkey; Type: CONSTRAINT; Schema: public; Owner: whynotadmin; Tablespace: 
--

ALTER TABLE ONLY file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: annotation_comment_index; Type: INDEX; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE INDEX annotation_comment_index ON annotation USING btree (comment_id);


--
-- Name: annotation_entry_index; Type: INDEX; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE INDEX annotation_entry_index ON annotation USING btree (entry_id);


--
-- Name: entry_databank_index; Type: INDEX; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE INDEX entry_databank_index ON entry USING btree (databank_id);


--
-- Name: entry_pdbid_index; Type: INDEX; Schema: public; Owner: whynotadmin; Tablespace: 
--

CREATE INDEX entry_pdbid_index ON entry USING btree (pdbid);


--
-- Name: fk1a21c74f15e6d2b4; Type: FK CONSTRAINT; Schema: public; Owner: whynotadmin
--

ALTER TABLE ONLY annotation
    ADD CONSTRAINT fk1a21c74f15e6d2b4 FOREIGN KEY (comment_id) REFERENCES comment(id);


--
-- Name: fk1a21c74fd01c454; Type: FK CONSTRAINT; Schema: public; Owner: whynotadmin
--

ALTER TABLE ONLY annotation
    ADD CONSTRAINT fk1a21c74fd01c454 FOREIGN KEY (entry_id) REFERENCES entry(id);


--
-- Name: fk4001852b073cd20; Type: FK CONSTRAINT; Schema: public; Owner: whynotadmin
--

ALTER TABLE ONLY entry
    ADD CONSTRAINT fk4001852b073cd20 FOREIGN KEY (file_id) REFERENCES file(id);


--
-- Name: fk4001852e88539e0; Type: FK CONSTRAINT; Schema: public; Owner: whynotadmin
--

ALTER TABLE ONLY entry
    ADD CONSTRAINT fk4001852e88539e0 FOREIGN KEY (databank_id) REFERENCES databank(id);


--
-- Name: fk6e8375063384fb9c; Type: FK CONSTRAINT; Schema: public; Owner: whynotadmin
--

ALTER TABLE ONLY databank
    ADD CONSTRAINT fk6e8375063384fb9c FOREIGN KEY (parent_id) REFERENCES databank(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: annotation; Type: ACL; Schema: public; Owner: whynotadmin
--

REVOKE ALL ON TABLE annotation FROM PUBLIC;
REVOKE ALL ON TABLE annotation FROM whynotadmin;
GRANT ALL ON TABLE annotation TO whynotadmin;
GRANT SELECT ON TABLE annotation TO whynotuser;


--
-- Name: comment; Type: ACL; Schema: public; Owner: whynotadmin
--

REVOKE ALL ON TABLE comment FROM PUBLIC;
REVOKE ALL ON TABLE comment FROM whynotadmin;
GRANT ALL ON TABLE comment TO whynotadmin;
GRANT SELECT ON TABLE comment TO whynotuser;


--
-- Name: databank; Type: ACL; Schema: public; Owner: whynotadmin
--

REVOKE ALL ON TABLE databank FROM PUBLIC;
REVOKE ALL ON TABLE databank FROM whynotadmin;
GRANT ALL ON TABLE databank TO whynotadmin;
GRANT SELECT ON TABLE databank TO whynotuser;


--
-- Name: entry; Type: ACL; Schema: public; Owner: whynotadmin
--

REVOKE ALL ON TABLE entry FROM PUBLIC;
REVOKE ALL ON TABLE entry FROM whynotadmin;
GRANT ALL ON TABLE entry TO whynotadmin;
GRANT SELECT ON TABLE entry TO whynotuser;


--
-- Name: file; Type: ACL; Schema: public; Owner: whynotadmin
--

REVOKE ALL ON TABLE file FROM PUBLIC;
REVOKE ALL ON TABLE file FROM whynotadmin;
GRANT ALL ON TABLE file TO whynotadmin;
GRANT SELECT ON TABLE file TO whynotuser;


--
-- PostgreSQL database dump complete
--

